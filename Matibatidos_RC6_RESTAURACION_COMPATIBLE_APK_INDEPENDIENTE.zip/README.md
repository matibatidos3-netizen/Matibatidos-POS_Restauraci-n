# Matibatidos POS RC6 — APK independiente

## Cambios de esta versión
- Importador compatible con el respaldo histórico `app/version/data.state` de Matibatidos.
- Recupera también las claves auxiliares de `data.storage`, usuarios y actividad.
- Identificador Android independiente: `com.matibatidos.pos.rc6`.
- Icono de la aplicación basado en el logo proporcionado de Matibatidos.
- Conserva el HTML funcional RC6 y los puentes Android incluidos en el proyecto.

## Compilación
Sube TODO el contenido de este ZIP directamente a la raíz del repositorio GitHub (incluida la carpeta oculta `.github`).
Después abre Actions > Compilar APK Matibatidos RC6 Independiente > Run workflow.
Descarga el artefacto `Matibatidos-POS-RC6-INDEPENDIENTE`.

## Importación del respaldo
En la nueva aplicación, inicia sesión con el usuario administrador que trae el respaldo y usa la opción Restaurar respaldo. La aplicación reconoce tanto `format: MATIBATIDOS_BACKUP` como el formato histórico que contiene `app`, `version` y `data.state`.

## Instalación independiente
La aplicación usa `applicationId` `com.matibatidos.pos.rc6`, diferente de `com.matibatidos.pos`; por tanto Android la instala como una aplicación separada. No desinstales la versión anterior.

## Precaución
La APK debug debe probarse en el dispositivo: restauración JSON, Excel, WhatsApp, permisos Bluetooth, impresora y respaldo externo. Mantén una copia adicional del JSON original.
