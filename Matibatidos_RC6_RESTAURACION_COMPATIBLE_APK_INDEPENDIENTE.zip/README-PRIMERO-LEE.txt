MATIBATIDOS POS RC6 - PROYECTO ANDROID

IMPORTANTE: este ZIP está preparado para que el contenido quede DIRECTAMENTE en la raíz del repositorio GitHub.

PASOS:
1. Descarga y extrae este ZIP en tu tablet.
2. Abre la carpeta Matibatidos_RC6_APK_ROOT.
3. Selecciona TODO lo que hay dentro, incluyendo .github, settings.gradle, build.gradle, gradle.properties y app.
4. Sube esos archivos y carpetas directamente a la raíz del repositorio GitHub. No subas la carpeta Matibatidos_RC6_APK_ROOT como una carpeta contenedora.
5. Comprueba que en la página principal del repositorio se vean settings.gradle, build.gradle, gradle.properties, app/ y .github/.
6. Abre Actions > Compilar APK Matibatidos RC6 > Run workflow.
7. Descarga el artefacto Matibatidos-POS-APK-RC6 cuando termine correctamente.

NO BORRES ni reemplaces la APK que usas actualmente hasta probar la nueva y restaurar un respaldo JSON.

El proyecto incluye el HTML RC6 adjunto y el código Android del empaquetado. La compilación debug no demuestra por sí sola que Bluetooth, WhatsApp, impresión y respaldo remoto funcionen en el dispositivo; deben probarse después de instalar.
