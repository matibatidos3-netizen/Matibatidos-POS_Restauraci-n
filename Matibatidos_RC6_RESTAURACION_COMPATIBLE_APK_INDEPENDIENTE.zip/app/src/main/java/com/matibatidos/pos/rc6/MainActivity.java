package com.matibatidos.pos.rc6;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 4102;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter bluetooth;
    private String printerAddress = "";

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(0xFF234C35);
        getWindow().setNavigationBarColor(0xFF183A29);
        bluetooth = BluetoothAdapter.getDefaultAdapter();
        printerAddress = getPreferences(MODE_PRIVATE).getString("printer_address", "");
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new FileSaver(), "AndroidFileSaver");
        webView.addJavascriptInterface(new WhatsAppBridge(), "AndroidWhatsApp");
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternal(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return handleExternal(url); }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                intent.setType("application/json");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(intent, FILE_CHOOSER); }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        requestBluetoothPermissions();
    }

    private boolean handleExternal(String raw) {
        try {
            Uri uri = Uri.parse(raw);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme();
            if (scheme.equals("file") || scheme.equals("about") || scheme.equals("data")) return false;
            if (scheme.equals("http") || scheme.equals("https") || scheme.equals("whatsapp") || scheme.equals("tel")) {
                Intent i = new Intent(Intent.ACTION_VIEW, uri); startActivity(i); return true;
            }
            return false;
        } catch (Exception e) { return true; }
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, 72);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = resultCode == RESULT_OK && data != null ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result); fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private String json(boolean ok, String key, String value) {
        try { JSONObject o = new JSONObject(); o.put("ok", ok); if (key != null) o.put(key, value); return o.toString(); }
        catch (Exception e) { return ok ? "{\"ok\":true}" : "{\"ok\":false}"; }
    }

    public class FileSaver {
        @JavascriptInterface public String saveBase64File(String filename, String mimeType, String base64Data) {
            try {
                byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                String safe = filename == null ? "Matibatidos_export" : filename.replaceAll("[/\\\\]", "_");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues(); values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Matibatidos");
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No se pudo crear el archivo en Descargas");
                    try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) { if (out == null) throw new Exception("No se pudo abrir el archivo"); out.write(bytes); }
                } else {
                    java.io.File dir = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Matibatidos");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("No se pudo crear la carpeta Descargas");
                    try (java.io.FileOutputStream out = new java.io.FileOutputStream(new java.io.File(dir, safe))) { out.write(bytes); }
                }
                return json(true, null, null);
            } catch (Exception e) { return json(false, "error", e.getMessage() == null ? "Error guardando archivo" : e.getMessage()); }
        }
    }

    public class WhatsAppBridge {
        @JavascriptInterface public String openWhatsApp(String number, String message) {
            try {
                String phone = number == null ? "" : number.replaceAll("[^0-9]", "");
                Uri uri = Uri.parse("https://wa.me/" + phone + "?text=" + Uri.encode(message == null ? "" : message));
                Intent i = new Intent(Intent.ACTION_VIEW, uri); i.setPackage("com.whatsapp");
                runOnUiThread(() -> { try { startActivity(i); } catch (Exception e) { try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {} } });
                return json(true, null, null);
            } catch (Exception e) { return json(false, "error", "No se pudo abrir WhatsApp"); }
        }
    }

    public class BackupBridge {
        @JavascriptInterface public String sendBackup(String endpoint, String payload) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(endpoint);
                if (!"https".equalsIgnoreCase(url.getProtocol())) return json(false, "error", "La URL debe usar HTTPS");
                conn = (HttpURLConnection) url.openConnection(); conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(30000);
                conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "text/plain;charset=utf-8");
                byte[] body = payload.getBytes("UTF-8"); conn.setFixedLengthStreamingMode(body.length);
                try (OutputStream out = conn.getOutputStream()) { out.write(body); }
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) return json(false, "error", "HTTP " + code);
                return json(true, null, null);
            } catch (Exception e) { return json(false, "error", e.getMessage() == null ? "Error de conexión" : e.getMessage()); }
            finally { if (conn != null) conn.disconnect(); }
        }
    }

    public class PrinterBridge {
        @JavascriptInterface public String openBluetoothSettings() {
            runOnUiThread(() -> { try { startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)); } catch (Exception ignored) {} });
            return json(true, null, null);
        }
        @JavascriptInterface public String selectPrinter() {
            if (!hasBluetoothPermission()) return json(false, "error", "Concede el permiso de dispositivos cercanos y vuelve a intentar");
            if (bluetooth == null) return json(false, "error", "Este dispositivo no tiene Bluetooth");
            final String[] result = new String[1]; final CountDownLatch latch = new CountDownLatch(1);
            runOnUiThread(() -> {
                try {
                    if (!bluetooth.isEnabled()) { result[0] = json(false, "error", "Activa Bluetooth en Android"); latch.countDown(); return; }
                    Set<BluetoothDevice> paired = bluetooth.getBondedDevices();
                    ArrayList<BluetoothDevice> devices = new ArrayList<>(paired);
                    if (devices.isEmpty()) { result[0] = json(false, "error", "Primero empareja la impresora en Ajustes Bluetooth"); latch.countDown(); return; }
                    String[] labels = new String[devices.size()];
                    for (int n=0;n<devices.size();n++) labels[n] = devices.get(n).getName() + " — " + devices.get(n).getAddress();
                    new AlertDialog.Builder(MainActivity.this).setTitle("Seleccionar impresora emparejada").setItems(labels, (d, which) -> {
                        BluetoothDevice dev = devices.get(which); printerAddress = dev.getAddress();
                        getPreferences(MODE_PRIVATE).edit().putString("printer_address", printerAddress).apply();
                        try { JSONObject o = new JSONObject(); o.put("ok", true); o.put("name", dev.getName()); o.put("address", printerAddress); result[0] = o.toString(); }
                        catch (Exception e) { result[0] = json(false, "error", "No se pudo guardar la impresora"); }
                        latch.countDown();
                    }).setOnCancelListener(d -> { result[0] = json(false, "error", "Selección cancelada"); latch.countDown(); }).show();
                } catch (Exception e) { result[0] = json(false, "error", e.getMessage()); latch.countDown(); }
            });
            try { if (!latch.await(90, TimeUnit.SECONDS)) return json(false, "error", "Tiempo de selección agotado"); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); return json(false, "error", "Selección interrumpida"); }
            return result[0];
        }
        @JavascriptInterface public String testConnection() { return connectAndWrite(new byte[]{0x1B,0x40,0x0A,0x0A}); }
        @JavascriptInterface public String printReceipt(String saleJson) {
            try {
                JSONObject s = new JSONObject(saleJson); StringBuilder b = new StringBuilder();
                b.append("\n       MATIBATIDOS\n"); b.append("FACTURA ").append(s.optString("invoice", "")).append("\n");
                b.append(s.optString("date", "")).append("\n--------------------------------\n");
                JSONArray items = s.optJSONArray("items");
                if (items != null) for (int i=0;i<items.length();i++) { JSONObject it=items.optJSONObject(i); if(it!=null) b.append(it.optInt("qty",1)).append(" x ").append(it.optString("name", "")).append("\n").append(String.format(java.util.Locale.US,"C$ %.2f",it.optDouble("price",0)*it.optDouble("qty",1))).append("\n"); }
                b.append("--------------------------------\nTOTAL: C$ ").append(String.format(java.util.Locale.US,"%.2f",s.optDouble("total",0))).append("\nPago: ").append(s.optString("pay", "")).append("\n\n\n");
                return connectAndWrite(b.toString().getBytes("UTF-8"));
            } catch (Exception e) { return json(false, "error", "No se pudo preparar el recibo"); }
        }
        private boolean hasBluetoothPermission() { return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED; }
        private String connectAndWrite(byte[] bytes) {
            if (!hasBluetoothPermission()) return json(false, "error", "Falta permiso Bluetooth. Revisa permisos de la aplicación");
            if (bluetooth == null || !bluetooth.isEnabled()) return json(false, "error", "Bluetooth no está activado");
            if (printerAddress == null || printerAddress.isEmpty()) return json(false, "error", "Selecciona primero una impresora Bluetooth");
            BluetoothSocket socket = null;
            try {
                BluetoothDevice device = bluetooth.getRemoteDevice(printerAddress);
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID); socket.connect();
                OutputStream out = socket.getOutputStream(); out.write(bytes); out.flush();
                return json(true, null, null);
            } catch (Exception e) { return json(false, "error", "No se pudo conectar/imprimir: " + (e.getMessage()==null?"verifica la impresora":e.getMessage())); }
            finally { try { if(socket!=null) socket.close(); } catch(Exception ignored){} }
        }
    }
}
